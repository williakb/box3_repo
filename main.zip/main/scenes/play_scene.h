#pragma once
#include "scene.h"

#ifdef __cplusplus
extern "C" {
#endif

scene_t* play_scene_get(void);

#ifdef __cplusplus
}
#endif
