#pragma once
#ifdef __cplusplus
extern "C" {
#endif

void game_start(void);

#ifdef __cplusplus
}
#endif
