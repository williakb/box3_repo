#include "input.h"
#include <math.h>
#include <string.h>

#include "lvgl.h"
#include "esp_lvgl_port.h"  // for lvgl_port_lock/unlock (ESP-IDF LVGL port)

#ifndef MIN
#define MIN(a,b) ((a)<(b)?(a):(b))
#endif
#ifndef MAX
#define MAX(a,b) ((a)>(b)?(a):(b))
#endif

typedef struct {
    input_state_t s;

    // For edge detection on action
    bool prev_action_down;

    // Virtual joystick state
    bool joy_tracking;
    int16_t joy_center_x;
    int16_t joy_center_y;

    // Tuning
    float deadzone;       // e.g. 0.10
    float max_radius_px;  // e.g. 80 px drag = full deflection
} input_ctx_t;

static input_ctx_t g;

static lv_indev_t* find_touch_indev(void) {
    lv_indev_t* indev = lv_indev_get_next(NULL);
    while (indev) {
        if (lv_indev_get_type(indev) == LV_INDEV_TYPE_POINTER) return indev;
        indev = lv_indev_get_next(indev);
    }
    return NULL;
}

static lv_indev_t* find_button_indev(void) {
    // Many BSPs register front button as LV_INDEV_TYPE_KEYPAD or LV_INDEV_TYPE_BUTTON.
    // We’ll accept either and treat it as a single "action" source.
    lv_indev_t* indev = lv_indev_get_next(NULL);
    while (indev) {
        lv_indev_type_t t = lv_indev_get_type(indev);
        if (t == LV_INDEV_TYPE_KEYPAD || t == LV_INDEV_TYPE_BUTTON) return indev;
        indev = lv_indev_get_next(indev);
    }
    return NULL;
}

static float apply_deadzone(float v, float dz) {
    float a = fabsf(v);
    if (a < dz) return 0.0f;
    // Rescale so it ramps from 0 at dz to 1 at 1
    float sign = (v >= 0.0f) ? 1.0f : -1.0f;
    float out = (a - dz) / (1.0f - dz);
    return sign * MIN(out, 1.0f);
}

static void update_joystick_from_touch(bool down, int16_t x, int16_t y) {
    g.s.touch_down = down;
    g.s.touch_x = x;
    g.s.touch_y = y;

    if (!down) {
        g.joy_tracking = false;
        g.s.joy_active = false;
        g.s.joy_x = 0.0f;
        g.s.joy_y = 0.0f;
        return;
    }

    if (!g.joy_tracking) {
        // Start of drag → define center
        g.joy_tracking = true;
        g.joy_center_x = x;
        g.joy_center_y = y;
        g.s.joy_active = true;
        g.s.joy_x = 0.0f;
        g.s.joy_y = 0.0f;
        return;
    }

    // Drag vector relative to center
    float dx = (float)(x - g.joy_center_x);
    float dy = (float)(y - g.joy_center_y);

    // Normalize by max radius
    float nx = dx / g.max_radius_px;
    float ny = dy / g.max_radius_px;

    // Clamp to unit circle
    float mag = sqrtf(nx*nx + ny*ny);
    if (mag > 1.0f && mag > 0.0f) {
        nx /= mag;
        ny /= mag;
    }

    // Deadzone + store (note: screen Y down; many games want up positive)
    nx = apply_deadzone(nx, g.deadzone);
    ny = apply_deadzone(ny, g.deadzone);

    g.s.joy_active = true;
    g.s.joy_x = nx;
    g.s.joy_y = -ny; // invert so dragging down is negative Y, up is positive
}

void input_init(void) {
    memset(&g, 0, sizeof(g));
    g.deadzone = 0.10f;
    g.max_radius_px = 80.0f;
}

void input_update(uint32_t dt_ms) {
    (void)dt_ms;

    // Clear one-tick pulses
    g.s.action_pressed = false;
    g.s.action_released = false;

if (!lvgl_port_lock(200)) {
    printf("LVGL LOCK FAILED in play_enter\n");
    return;
}
printf("LVGL LOCK OK in play_enter\n");

    // 1) Touch -> virtual joystick
    lv_indev_t* touch = find_touch_indev();
    if (touch) {
        lv_indev_data_t data;
        memset(&data, 0, sizeof(data));

        _lv_indev_read(touch, &data);

        bool down = (data.state == LV_INDEV_STATE_PRESSED);
        update_joystick_from_touch(down, (int16_t)data.point.x, (int16_t)data.point.y);
    } else {
        update_joystick_from_touch(false, 0, 0);
    }

    // 2) Front button (as LVGL indev: KEYPAD or BUTTON)
    lv_indev_t* btn = find_button_indev();
    bool action_down = false;

    if (btn) {
        lv_indev_data_t b;
        memset(&b, 0, sizeof(b));

        _lv_indev_read(btn, &b);

        // For KEYPAD: b.key has last key; for BUTTON it may be 0.
        // Easiest generic behavior: pressed state = action_down.
        action_down = (b.state == LV_INDEV_STATE_PRESSED);

        // If you want "any key pressed" requirement for keypad, use:
        // if (lv_indev_get_type(btn) == LV_INDEV_TYPE_KEYPAD) {
        //     action_down = action_down && (b.key != 0);
        // }
    }

    lvgl_port_unlock();

    // Edge detection
    g.s.action_down = action_down;
    if (action_down && !g.prev_action_down) g.s.action_pressed = true;
    if (!action_down && g.prev_action_down) g.s.action_released = true;
    g.prev_action_down = action_down;
}

input_state_t input_get_state(void) {
    return g.s; // returns a copy
}